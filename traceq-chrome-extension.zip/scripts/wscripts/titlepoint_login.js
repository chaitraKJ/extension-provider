console.log("TraceQ - Titlepoint-Login script injected");

let username_input = null;
let password_input = null;

var s = function (sketch){
	sketch.setup = function(){
		console.log("p5 sketch extension");
		try{
			document.body.style.userSelect = "none";
			const body = document.querySelector("body");

			let h = document.body.clientHeight;
			let c = sketch.createCanvas(sketch.windowWidth,  h);
			c.parent(body);
			c.position(0, 0);
			c.style('pointer-events', 'none');
			sketch.clear();
		}
		catch(error){
			console.log("TraceQ Extension Content-Script P5 Error: "+error);
		}	
	};

	sketch.draw = function(){
		try{
			sketch.clear();
			const coords = password_input.getBoundingClientRect();
			const x1 = coords.left + window.scrollX;
			const y1 = coords.top + window.scrollY + 19;
			const x2 = x1 + coords.width;

			sketch.stroke(0);
			sketch.strokeWeight(coords.height);
			sketch.line(x1, y1, x2, y1);
		}
		catch(error){
			console.log("TraceQ Extension Content-Script P5 Error: "+error);
		}		
	};
};

let application_id = null;
chrome.storage.local.get(["titlePoint_app_id"]).then(async (result) => {
	try{
		application_id = result['titlePoint_app_id'];
		if(application_id){
			const message = {
				type: "APP_DATA",
				tab: "NONE",
				application_id: application_id
			}
			await chrome.runtime.sendMessage(message);
			await chrome.storage.local.remove(["titlePoint_app_id"], () => { 
				console.log("TitlePoint Storage Cleared");
				var error = chrome.runtime.lastError;
				if (error) {
					console.error(error);
				} 
			});
		}
	}
	catch(error){
		console.log("TraceQ Extension Content-Script Error: "+error);
	}	
});

function handleMessages(message, sender, sendResponse) {
	try{
		if(message['type'] == "CREDENTIAL"){ 
			const username = message['username'];
			const password = message['password'];

			const mainInterval = setInterval(() => {	
				try{
					const main_div = document.querySelector("#signin-container");
					const next_btn = main_div.querySelector("#form20 input[type='submit']");
					username_input = main_div.querySelector("#input28");  

					if(next_btn && username_input){
						clearInterval(mainInterval);

						username_input.setAttribute("readonly", true);
						username_input.value = username;
						username_input.dispatchEvent(new Event("input", { bubbles: true, cancelable: true }));
						next_btn.click();

						let interval = setInterval(() => {
							try{
								password_input = document.getElementById("input61");
								if(password_input){
									clearInterval(interval);

									var myp5 = new p5(s);
									password_input.setAttribute("readonly", true);
									password_input.style.filter = "blur(5px)";															
									password_input.value = password;
									password_input.dispatchEvent(new Event("input", { bubbles: true, cancelable: true }));
								}
							}
							catch(error){
								console.log("TraceQ Extension Content-Script Error: "+error);
							}							
						}, 1000);
					}
				}
				catch(error){
					console.log("TraceQ Extension Content-Script Error: "+error);
				}
			}, 1000);
		}
	}
	catch(error){
		console.log("TraceQ Extension Content-Script Error: "+error);
	}
}
chrome.runtime.onMessage.addListener(handleMessages);