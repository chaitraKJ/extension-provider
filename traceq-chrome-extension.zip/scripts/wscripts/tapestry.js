console.log("TraceQ - Tapestry script injected")

let username_input = null;
let password_input = null;

var s = function (sketch){
	sketch.setup = function(){
		console.log("p5 sketch extension");
		try{
			document.body.style.userSelect = "none";
			let h = document.body.clientHeight;
			let c = sketch.createCanvas(sketch.windowWidth, h);
			c.position(0, 0);
			c.style('pointer-events', 'none');
			sketch.clear();
		}
		catch(error){
			console.log("TraceQ Extension Content-Script P5 Error: "+error);
		}		
	};

	sketch.draw = function(){ 
		try{
			sketch.clear();
			const coords = password_input.getBoundingClientRect();
			const x1 = coords.left + window.scrollX;
			const y1 = coords.top + window.scrollY + 9;
			const x2 = x1 + coords.width;

			sketch.stroke(0);
			sketch.strokeWeight(coords.height);
			sketch.line(x1, y1, x2, y1);
		}
		catch(error){
			console.log("TraceQ Extension Content-Script P5 Error: "+error);
		}	
	};
};

function handleMessages(message, sender, sendResponse) {
	if(message['type'] == "CREDENTIAL"){
		const main_div = document.getElementById("Login");
		const login_btn = main_div.querySelector("#btnLogin");

		username_input = main_div.querySelector("#LoginView1_Login1_UserName");
		password_input = main_div.querySelector("#LoginView1_Login1_Password");

		if(login_btn){
			chrome.storage.local.set({ tapestry_app_id: message['application_id'] })
			.then(() => {
				login_btn.click();
			})
			.catch((error) => {
				console.log(error);
			});
		}
		if(username_input && password_input){
			var myp5 = new p5(s);
			username_input.value = message['username'];
			password_input.value = message['password'];

			username_input.setAttribute("readonly", true);
			password_input.setAttribute("readonly", true);
			password_input.style.filter = "blur(5px)";
		}
	}
}
chrome.runtime.onMessage.addListener(handleMessages);


chrome.storage.local.get(["tapestry_app_id"]).then(async (result) => {
	try{
		application_id = result['tapestry_app_id'];
		if(application_id){
			const message = {
				type: "APP_DATA",
				tab: "NONE",
				application_id: application_id
			}
			await chrome.runtime.sendMessage(message);
			await chrome.storage.local.remove(["tapestry_app_id"], () => { 
				console.log("Fidlar Storage Cleared");
				var error = chrome.runtime.lastError;
				if (error) {
					console.error(error);
				}
			});
		}
	}
	catch(error){
		console.log("TraceQ Extension Content-Script Error: "+error);
	}	
});