console.log("TraceQ - Titlepoint-Dashboard script injected")

function handleMessages(message, sender, sendResponse) {
	try{
		if(message['type'] == "CREDENTIAL"){
			const login_btn = document.querySelector("#btnLogin");
			if(login_btn){
				chrome.storage.local.set({ titlePoint_app_id: message['application_id'] })
				.then(() => {
					login_btn.click();
				})
				.catch((error) => {
					console.log(error);
				});		
			}
		}
	}
	catch(error){
		console.log("TraceQ Extension Content-Script Error: "+error);
	}	
}
chrome.runtime.onMessage.addListener(handleMessages);