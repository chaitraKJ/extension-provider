console.log("TraceQ - DoxPop script injected");

let username_input = null;
let password_input = null;

var s = function (sketch){
	sketch.setup = function(){
		console.log("p5 sketch extension");
		try{
			document.body.style.userSelect = "none";
			let h = document.body.clientHeight;
			let c = sketch.createCanvas(sketch.windowWidth, h);
			c.position(0, 0);
			c.style('pointer-events', 'none');
			sketch.clear();
		}
		catch(error){
			console.log("TraceQ Extension Content-Script P5 Error: "+error);
		}		
	};

	sketch.draw = function(){
		try{
			sketch.clear();
			const coords = password_input.getBoundingClientRect();
			const x1 = coords.left + window.scrollX;
			const y1 = coords.top + window.scrollY + 9;
			const x2 = x1 + coords.width;

			sketch.stroke(0);
			sketch.strokeWeight(coords.height);
			sketch.line(x1, y1, x2, y1);
		}
		catch(error){
			console.log("TraceQ Extension Content-Script P5 Error: "+error);
		}
	};
};

function handleMessages(message, sender, sendResponse) {
	try{
		if(message['type'] == "CREDENTIAL"){
			username_input = document.getElementById("username");
			password_input = document.getElementById("PASSWORD");

			var myp5 = new p5(s);
			if(username_input && password_input){
				username_input.setAttribute("readonly", true);
				password_input.setAttribute("readonly", true);
				password_input.style.filter = "blur(5px)";

				username_input.value = message['username'];
				password_input.value = message['password'];	
			}
		}
	}
	catch(error){
		console.log("TraceQ Extension Content-Script Error: "+error);
	}
}
chrome.runtime.onMessage.addListener(handleMessages);