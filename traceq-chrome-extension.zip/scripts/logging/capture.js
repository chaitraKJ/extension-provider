console.log("TraceQ Logger is running");

class Capture{
	constructor(){
		this.user = "";	 
		this.url = "";
		
		this.body = document.querySelector('body');

		this.get_logged_user();
		this.get_website_info();
		this.inject_logger();
	}
	get_logged_user(){
		let obj = this;
		chrome.storage.local.get(["traceq_logged_user"]).then((result) => {
			try{
				obj.user = result['traceq_logged_user'] ?? "Anon";				
			}
			catch(error){
				console.log("TraceQ Extension Content-Script Error: "+error);
			}	
		});
	}
	get_website_info(){
		this.url = window.origin;
	}
	inject_logger(){
		let obj = this;		
		if(obj.url.includes("tapestry.fidlar.com")){
			obj.tapestry();
		}
		else if(obj.url.includes("icounty.org")){
			obj.icounty();
		}
	}
	tapestry(){
		const SEARCH_BTN_ID = "ContentPlaceHolder1_btnSearch";
		const AMOUNT_ID = "ContentPlaceHolder1_lblDataSourceSearchPrice";

		document.getElementById(SEARCH_BTN_ID)?.addEventListener("click", () => {
			try{
				const amount_div = document.getElementById(AMOUNT_ID);
				if(amount_div){
					let amount = amount_div.textContent.trim();
					amount = amount.split(" ");
					amount = amount[amount.length - 1];
					this.send_activity("SEARCH", "FIDLAR", amount);
				}
			}
			catch(error){
				console.log(error);
			}			
		});
	}
	icounty(){
		const FORM_ID = "Payment_Card_Info";
		const SUBMIT_BTN_ID = "btnSubmit";
		const AMOUNT_ID = "lblCharges";

		document.querySelector(`#${FORM_ID} #${SUBMIT_BTN_ID}`)?.addEventListener("click", (e) => {
			try{
				const amount_div = document.getElementById(AMOUNT_ID);
				if(amount_div){
					const table_tbody = amount_div?.querySelector("table tbody");
					if(table_tbody){
						const amount = table_tbody?.lastElementChild?.querySelector('td')?.textContent.trim();
						this.send_activity("SUBSCRIPTION", "ICOUNTY", amount);
					}
				}
			}
			catch(error){
				console.log(error);
			}
		});
	}
	async send_activity(activity, application="", amount=null){
		try{
			const data = {
				user: this.user,
				application: application,
				url: this.url,
				activity: activity,
				amount: amount
			};
			const message = {
				type: "USER_ACTIVITY",
				data: data
			};
			await chrome.runtime.sendMessage(message);
		}
		catch(error){
			console.log(error);
		}			
	}
}

new Capture();